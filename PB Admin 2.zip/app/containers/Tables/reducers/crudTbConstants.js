export const FETCH_DATA = 'FETCH_DATA';
export const ADD_EMPTY_ROW = 'ADD_EMPTY_ROW';
export const UPDATE_ROW = 'UPDATE_ROW';
export const REMOVE_ROW = 'REMOVE_ROW';
export const EDIT_ROW = 'EDIT_ROW';
export const SAVE_ROW = 'SAVE_ROW';

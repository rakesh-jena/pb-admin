import { Record } from 'immutable';

const Init = new Record({
  completed: false,
  key: null,
  title: null
});

export default Init;

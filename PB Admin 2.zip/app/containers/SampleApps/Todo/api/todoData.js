const todoData = [
  {
    key: '1',
    title: 'Lorem ipsum dolor sit amet',
    completed: false,
  },
  {
    key: '2',
    title: 'Sed imperdiet enim ligula',
    completed: true,
  },
  {
    key: '3',
    title: 'Cras convallis',
    completed: false,
  },
  {
    key: '4',
    title: 'Integer orci justo',
    completed: false,
  },
  {
    key: '5',
    title: 'Nam posuere accumsan porta',
    completed: true,
  },
  {
    key: '6',
    title: 'Lorem ipsum dolor sit amet',
    completed: false,
  },
  {
    key: '7',
    title: 'Sed imperdiet enim ligula',
    completed: true,
  },
  {
    key: '8',
    title: 'Cras convallis',
    completed: false,
  },
  {
    key: '9',
    title: 'Integer orci justo',
    completed: false,
  },
  {
    key: '10',
    title: 'Nam posuere accumsan porta',
    completed: true,
  },
];

export default todoData;

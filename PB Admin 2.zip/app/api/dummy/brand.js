module.exports = {
  name: 'ParkinBuddy',
  desc: 'ParkinBuddy - An App For Booking Parking Spot',
  prefix: 'pb',
  footerText: 'ParkinBuddy All Rights Reserved 2023',
  logoText: 'ParkinBuddy',
};

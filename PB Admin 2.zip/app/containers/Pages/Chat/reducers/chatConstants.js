export const FETCH_CHAT_DATA = 'FETCH_CHAT_DATA';
export const SHOW_CHAT = 'SHOW_CHAT';
export const HIDE_CHAT = 'HIDE_CHAT';
export const SEND_CHAT = 'SEND_CHAT';
export const DELETE_CONVERSATION = 'DELETE_CONVERSATION';

const styles = {
  chartFluid: {
    width: '100%',
    minWidth: 500,
    height: 450
  }
};

export default styles;

export const LOAD_TASKS_DATA = 'LOAD_TASKS_DATA';
export const ADD_TASK = 'ADD_TASK';
export const DELETE_TASK = 'DELETE_TASK';
export const EDIT_TASK = 'EDIT_TASK';
export const FILTER_TASKS_DATA = 'FILTER_TASKS_DATA';

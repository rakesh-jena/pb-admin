const chatData = [
  {
    with: '1',
    chat: [
      {
        id: '1_1',
        from: 'contact',
        date: 'May, 29 2018',
        time: '22:45',
        message: 'Lorem ipsum dolor sit amet'
      },
      {
        id: '1_2',
        from: 'me',
        date: 'May, 29 2018',
        time: '22:45',
        message: 'Pellentesque ac bibendum tortor'
      },
      {
        id: '1_3',
        from: 'contact',
        date: 'May, 30 2018',
        time: '09:20',
        message: 'Sed imperdiet enim ligula, vitae viverra justo porta vel. Duis eget felis bibendum, pretium mi sed, placerat ante. '
      },
      {
        id: '1_4',
        from: 'me',
        date: 'May, 30 2018',
        time: '09:55',
        message: 'Curabitur egestas consequat lorem, vel fermentum augue porta id. Aliquam lobortis magna neque'
      },
      {
        id: '1_5',
        from: 'me',
        date: 'May, 30 2018',
        time: '09:58',
        message: 'Integer orci justo'
      },
      {
        id: '1_6',
        from: 'contact',
        date: 'May, 30 2018',
        time: '09:58',
        message: 'Nam posuere accumsan porta. Integer id orci sed ante tincidunt tincidunt sit amet sed libero. Quisque ut metus sit amet augue rutrum feugiat. Vestibulum bibendum nisi eget magna malesuada'
      },
    ]
  },
  {
    with: '2',
    chat: [
      {
        id: '2_1',
        from: 'contact',
        date: 'May, 29 2018',
        time: '22:45',
        message: 'Lorem ipsum dolor sit amet'
      },
      {
        id: '2_2',
        from: 'me',
        date: 'May, 29 2018',
        time: '22:45',
        message: 'Pellentesque ac bibendum tortor'
      },
      {
        id: '2_3',
        from: 'contact',
        date: 'May, 30 2018',
        time: '09:20',
        message: 'Sed imperdiet enim ligula, vitae viverra justo porta vel. Duis eget felis bibendum, pretium mi sed, placerat ante. '
      },
    ]
  },
  {
    with: '3',
    chat: [
      {
        id: '3_1',
        from: 'contact',
        date: 'May, 29 2018',
        time: '22:45',
        message: 'Lorem ipsum dolor sit amet'
      },
      {
        id: '3_2',
        from: 'me',
        date: 'May, 29 2018',
        time: '22:45',
        message: 'Pellentesque ac bibendum tortor'
      },
    ]
  },
  {
    with: '4',
    chat: [
      {
        id: '4_1',
        from: 'contact',
        date: 'May, 30 2018',
        time: '09:20',
        message: 'Sed imperdiet enim ligula, vitae viverra justo porta vel. Duis eget felis bibendum, pretium mi sed, placerat ante. '
      },
      {
        id: '4_2',
        from: 'me',
        date: 'May, 30 2018',
        time: '09:55',
        message: 'Curabitur egestas consequat lorem, vel fermentum augue porta id. Aliquam lobortis magna neque'
      },
      {
        id: '4_3',
        from: 'me',
        date: 'May, 30 2018',
        time: '09:58',
        message: 'Integer orci justo'
      },
      {
        id: '4_4',
        from: 'contact',
        date: 'May, 30 2018',
        time: '09:58',
        message: 'Nam posuere accumsan porta. Integer id orci sed ante tincidunt tincidunt sit amet sed libero. Quisque ut metus sit amet augue rutrum feugiat. Vestibulum bibendum nisi eget magna malesuada'
      },
    ]
  },
  {
    with: '5',
    chat: [],
  },
  {
    with: '6',
    chat: [],
  },
];

export default chatData;
